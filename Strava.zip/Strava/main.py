import sys
import os

# Use imports without scripts. prefix now
from scripts.load_data import safe_read
from scripts.plots_sleep import plot_sleep_efficiency
from scripts.plots_steps import plot_steps_by_hour
from scripts.plots_calories import plot_calories_vs_steps
from scripts.plots_bmi import plot_bmi_vs_steps
from scripts.plots_hr import plot_avg_heart_rate
from scripts.plots_mets import plot_mets_by_hour
from scripts.export_final import export_summary

def main():
    print("Running Bellabeat Data Analysis Project...")
    
    try:
        # Generate visualization plots
        plot_sleep_efficiency()
        plot_steps_by_hour()
        plot_calories_vs_steps()
        plot_bmi_vs_steps()
        plot_avg_heart_rate()
        plot_mets_by_hour()

        # Generate final report
        export_summary()

        print("\nAll tasks completed!")
        
    except Exception as e:
        print(f"\nError occurred: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()