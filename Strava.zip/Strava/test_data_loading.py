from scripts.load_data import safe_read

def test_data_loading():
    """Test loading all required data files."""
    
    print("\n🔍 Testing Data Loading...")
    print("=======================")
    
    # Test loading each required file
    files_to_test = [
        'dailyActivity_merged.csv',
        'sleepDay_merged.csv',
        'heartrate_seconds_merged.csv',
        'weightLogInfo_merged.csv',
        'minuteMETsNarrow_merged.csv',
        'hourlySteps_merged.csv'
    ]
    
    for filename in files_to_test:
        df = safe_read(filename)
        if not df.empty:
            print(f"✅ Successfully loaded {filename}")
            print(f"   Columns: {', '.join(df.columns)}\n")
        else:
            print(f"❌ Failed to load {filename}\n")

if __name__ == "__main__":
    test_data_loading() 