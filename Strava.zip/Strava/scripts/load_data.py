import pandas as pd
import os

# ✅ Set your data folder path
BASE_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')

def safe_read(filename):
    """
    Safely read a CSV file from the data directory.
    
    Args:
        filename (str): Name of the CSV file to read
        
    Returns:
        pandas.DataFrame: The loaded data or an empty DataFrame if loading fails
    """
    try:
        # Create data directory if it doesn't exist
        os.makedirs(BASE_PATH, exist_ok=True)
        
        # Build full path and read file
        full_path = os.path.join(BASE_PATH, filename)
        if not os.path.exists(full_path):
            print(f"❌ File not found: {filename}")
            return pd.DataFrame()
            
        df = pd.read_csv(full_path)
        print(f"✅ Loaded: {filename} — shape: {df.shape}")
        return df
        
    except Exception as e:
        print(f"❌ Failed to load {filename}: {e}")
        return pd.DataFrame()