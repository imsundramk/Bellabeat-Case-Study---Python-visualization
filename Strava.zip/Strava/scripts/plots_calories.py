import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from .load_data import safe_read

def plot_calories_vs_steps():
    """
    Create and save a scatter plot showing the relationship between daily calories burned and steps taken.
    """
    # Load daily activity data
    daily_data = safe_read('dailyActivity_merged.csv')
    
    if daily_data.empty:
        print("❌ No daily activity data available to plot")
        return
        
    try:
        # Create the plot
        plt.figure(figsize=(10, 6))
        
        # Create scatter plot with regression line
        sns.regplot(data=daily_data, 
                   x='TotalSteps',  # Using correct column name
                   y='Calories',
                   scatter_kws={'alpha':0.5, 'color':'blue'},
                   line_kws={'color': 'red'})
        
        # Calculate correlation coefficient
        correlation = daily_data['TotalSteps'].corr(daily_data['Calories'])
        
        # Customize the plot
        plt.title('Daily Calories Burned vs Steps Taken')
        plt.xlabel('Total Steps')
        plt.ylabel('Calories Burned')
        plt.grid(True, linestyle='--', alpha=0.7)
        
        # Add correlation annotation
        plt.text(0.05, 0.95, 
                f'Correlation: {correlation:.2f}', 
                transform=plt.gca().transAxes,
                bbox=dict(facecolor='white', alpha=0.8))
        
        # Adjust layout and save
        plt.tight_layout()
        plt.savefig('outputs/calories_vs_steps.png')
        plt.close()
        
        print("✅ Calories vs steps plot generated successfully")
        
    except Exception as e:
        print(f"❌ Error generating calories plot: {str(e)}")