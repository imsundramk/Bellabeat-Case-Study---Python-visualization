import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from .load_data import safe_read

def plot_mets_by_hour():
    """
    Create and save a plot showing METs (Metabolic Equivalent of Task) distribution by hour.
    """
    # Load minuteMETs data
    mets_data = safe_read('minuteMETsNarrow_merged.csv')
    
    if mets_data.empty:
        print("❌ No METs data available to plot")
        return
        
    try:
        # Process the data
        mets_data['ActivityMinute'] = pd.to_datetime(mets_data['ActivityMinute'])
        mets_data['Hour'] = mets_data['ActivityMinute'].dt.hour
        
        # Calculate hourly statistics
        hourly_mets = mets_data.groupby('Hour')['METs'].agg(['mean', 'std', 'count']).reset_index()
        
        # Create the plot
        plt.figure(figsize=(12, 6))
        
        # Create bar plot with error bars
        plt.bar(hourly_mets['Hour'], 
               hourly_mets['mean'],
               yerr=hourly_mets['std'],
               alpha=0.7,
               color='purple',
               capsize=5)
        
        # Customize the plot
        plt.title('Average METs by Hour of Day')
        plt.xlabel('Hour (24-hour format)')
        plt.ylabel('Average METs')
        plt.grid(True, axis='y', linestyle='--', alpha=0.7)
        
        # Set x-axis ticks to show all hours
        plt.xticks(range(24))
        
        # Add value labels on top of each bar
        for i, row in hourly_mets.iterrows():
            plt.text(row['Hour'], row['mean'], 
                    f'{row["mean"]:.1f}',
                    ha='center', va='bottom')
        
        # Adjust layout and save
        plt.tight_layout()
        plt.savefig('outputs/mets_by_hour.png')
        plt.close()
        
        print("✅ METs by hour plot generated successfully")
        
    except Exception as e:
        print(f"❌ Error generating METs plot: {str(e)}")


