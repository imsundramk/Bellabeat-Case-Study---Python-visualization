import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from .load_data import safe_read

def plot_bmi_vs_steps():
    """
    Create and save a scatter plot showing the relationship between BMI and daily steps.
    """
    # Load weight and activity data
    weight_data = safe_read('weightLogInfo_merged.csv')
    activity_data = safe_read('dailyActivity_merged.csv')
    
    if weight_data.empty or activity_data.empty:
        print("No weight or activity data available to plot")
        return
        
    try:
        # Process and merge data
        weight_data['Date'] = pd.to_datetime(weight_data['Date']).dt.date
        activity_data['Date'] = pd.to_datetime(activity_data['ActivityDate']).dt.date
        
        # Merge on date
        merged_data = pd.merge(weight_data, activity_data, 
                             left_on='Date', 
                             right_on='Date',
                             how='inner')
        
        if merged_data.empty:
            print("No matching dates between weight and activity data")
            return
            
        # Create the plot
        plt.figure(figsize=(10, 6))
        
        # Create scatter plot with regression line
        sns.regplot(data=merged_data, 
                   x='TotalSteps',
                   y='BMI',
                   scatter_kws={'alpha':0.5, 'color':'green'},
                   line_kws={'color': 'red'})
        
        # Calculate correlation coefficient
        correlation = merged_data['TotalSteps'].corr(merged_data['BMI'])
        
        # Customize the plot
        plt.title('BMI vs Daily Steps')
        plt.xlabel('Total Steps')
        plt.ylabel('BMI')
        plt.grid(True, linestyle='--', alpha=0.7)
        
        # Add correlation annotation
        plt.text(0.05, 0.95, 
                f'Correlation: {correlation:.2f}', 
                transform=plt.gca().transAxes,
                bbox=dict(facecolor='white', alpha=0.8))
        
        # Adjust layout and save
        plt.tight_layout()
        plt.savefig('outputs/bmi_vs_steps.png')
        plt.close()
        
        print("BMI vs steps plot generated successfully")
        
    except Exception as e:
        print(f"Error generating BMI plot: {str(e)}")