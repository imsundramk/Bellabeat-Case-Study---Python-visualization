import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from .load_data import safe_read

def plot_avg_heart_rate():
    """
    Create and save a plot showing average heart rate patterns throughout the day.
    """
    # Load heart rate data
    heartrate_data = safe_read('heartrate_seconds_merged.csv')
    
    if heartrate_data.empty:
        print("No heart rate data available to plot")
        return
        
    try:
        # Process the data
        heartrate_data['Time'] = pd.to_datetime(heartrate_data['Time'])
        heartrate_data['Hour'] = heartrate_data['Time'].dt.hour
        
        # Calculate hourly averages
        hourly_hr = heartrate_data.groupby('Hour')['Value'].agg(['mean', 'std']).reset_index()
        
        # Create the plot
        plt.figure(figsize=(12, 6))
        
        # Plot average heart rate with confidence interval
        plt.plot(hourly_hr['Hour'], hourly_hr['mean'], color='red', linewidth=2)
        plt.fill_between(hourly_hr['Hour'],
                        hourly_hr['mean'] - hourly_hr['std'],
                        hourly_hr['mean'] + hourly_hr['std'],
                        alpha=0.2, color='red')
        
        # Customize the plot
        plt.title('Average Heart Rate Throughout the Day')
        plt.xlabel('Hour of Day (24-hour format)')
        plt.ylabel('Heart Rate (BPM)')
        plt.grid(True, linestyle='--', alpha=0.7)
        
        # Set x-axis ticks to show all hours
        plt.xticks(range(24))
        
        # Add min/max annotations
        max_hr = hourly_hr.loc[hourly_hr['mean'].idxmax()]
        min_hr = hourly_hr.loc[hourly_hr['mean'].idxmin()]
        
        plt.annotate(f'Max: {max_hr["mean"]:.0f} BPM',
                    xy=(max_hr['Hour'], max_hr['mean']),
                    xytext=(10, 10), textcoords='offset points')
        plt.annotate(f'Min: {min_hr["mean"]:.0f} BPM',
                    xy=(min_hr['Hour'], min_hr['mean']),
                    xytext=(10, -10), textcoords='offset points')
        
        # Adjust layout and save
        plt.tight_layout()
        plt.savefig('outputs/avg_heart_rate.png')
        plt.close()
        
        print("Average heart rate plot generated successfully")
        
    except Exception as e:
        print(f"Error generating heart rate plot: {str(e)}")



