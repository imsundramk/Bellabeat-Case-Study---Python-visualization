import pandas as pd
import numpy as np
from datetime import datetime
from .load_data import safe_read

def export_summary():
    """
    Create and save a summary report of the fitness tracking data analysis.
    """
    try:
        # Load all required datasets
        daily_activity = safe_read('dailyActivity_merged.csv')
        sleep_data = safe_read('sleepDay_merged.csv')
        heart_rate = safe_read('heartrate_seconds_merged.csv')
        weight_data = safe_read('weightLogInfo_merged.csv')
        
        summary = []
        summary.append("BELLABEAT FITNESS DATA ANALYSIS SUMMARY")
        summary.append("=====================================")
        summary.append(f"Report generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        
        # Activity Summary
        if not daily_activity.empty:
            summary.append("ACTIVITY SUMMARY")
            summary.append("-----------------")
            summary.append(f"Total days tracked: {len(daily_activity)}")
            summary.append(f"Average daily steps: {daily_activity['TotalSteps'].mean():,.0f}")
            summary.append(f"Average daily calories: {daily_activity['Calories'].mean():,.0f}")
            summary.append(f"Most active day: {daily_activity.loc[daily_activity['TotalSteps'].idxmax(), 'ActivityDate']} ({daily_activity['TotalSteps'].max():,.0f} steps)")
            summary.append(f"Average very active minutes: {daily_activity['VeryActiveMinutes'].mean():.1f}")
            summary.append("")
        
        # Sleep Summary
        if not sleep_data.empty:
            summary.append("SLEEP SUMMARY")
            summary.append("--------------")
            summary.append(f"Total nights tracked: {len(sleep_data)}")
            avg_sleep = sleep_data['TotalMinutesAsleep'].mean()
            avg_bed = sleep_data['TotalTimeInBed'].mean()
            summary.append(f"Average sleep time: {avg_sleep/60:.1f} hours ({avg_sleep:.0f} minutes)")
            summary.append(f"Average time in bed: {avg_bed/60:.1f} hours ({avg_bed:.0f} minutes)")
            summary.append(f"Sleep efficiency: {(avg_sleep/avg_bed*100):.1f}%")
            summary.append("")
        
        # Heart Rate Summary
        if not heart_rate.empty:
            summary.append("HEART RATE SUMMARY")
            summary.append("-------------------")
            summary.append(f"Total measurements: {len(heart_rate):,}")
            summary.append(f"Average heart rate: {heart_rate['Value'].mean():.0f} BPM")
            summary.append(f"Maximum heart rate: {heart_rate['Value'].max():.0f} BPM")
            summary.append(f"Minimum heart rate: {heart_rate['Value'].min():.0f} BPM")
            summary.append(f"Standard deviation: {heart_rate['Value'].std():.1f} BPM")
            summary.append("")
        
        # Weight & BMI Summary
        if not weight_data.empty:
            summary.append("WEIGHT & BMI SUMMARY")
            summary.append("-------------------")
            summary.append(f"Total weigh-ins: {len(weight_data)}")
            summary.append(f"Average weight: {weight_data['WeightKg'].mean():.1f} kg")
            summary.append(f"Weight change: {weight_data['WeightKg'].iloc[-1] - weight_data['WeightKg'].iloc[0]:.1f} kg")
            summary.append(f"Average BMI: {weight_data['BMI'].mean():.1f}")
            summary.append(f"BMI category: {get_bmi_category(weight_data['BMI'].mean())}")
            summary.append("")
        
        # Correlations
        if not daily_activity.empty:
            summary.append("KEY CORRELATIONS")
            summary.append("----------------")
            steps_calories_corr = daily_activity['TotalSteps'].corr(daily_activity['Calories'])
            summary.append(f"Steps vs Calories correlation: {steps_calories_corr:.2f}")
            if not weight_data.empty:
                # Merge weight and activity data for BMI correlation
                weight_data['Date'] = pd.to_datetime(weight_data['Date']).dt.date
                activity_data = daily_activity.copy()
                activity_data['Date'] = pd.to_datetime(activity_data['ActivityDate']).dt.date
                merged = pd.merge(weight_data, activity_data, on='Date', how='inner')
                if not merged.empty:
                    bmi_steps_corr = merged['BMI'].corr(merged['TotalSteps'])
                    summary.append(f"BMI vs Steps correlation: {bmi_steps_corr:.2f}")
            summary.append("")
        
        # Save summary to file
        with open('outputs/analysis_summary.txt', 'w', encoding='utf-8') as f:
            f.write('\n'.join(summary))
        
        print("Analysis summary exported successfully")
        
    except Exception as e:
        print(f"Error exporting summary: {str(e)}")

def get_bmi_category(bmi):
    """Return BMI category based on WHO classification."""
    if bmi < 18.5:
        return "Underweight"
    elif bmi < 25:
        return "Normal weight"
    elif bmi < 30:
        return "Overweight"
    else:
        return "Obese"