import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from .load_data import safe_read

def plot_steps_by_hour():
    """
    Create and save a plot showing average steps taken by hour of the day.
    """
    # Load hourly steps data
    hourly_data = safe_read('hourlySteps_merged.csv')
    
    if hourly_data.empty:
        print("❌ No hourly steps data available to plot")
        return
        
    try:
        # Process the data
        hourly_data['ActivityHour'] = pd.to_datetime(hourly_data['ActivityHour'])
        hourly_data['Hour'] = hourly_data['ActivityHour'].dt.hour
        
        # Calculate average steps for each hour
        hourly_avg = hourly_data.groupby('Hour')['StepTotal'].mean().reset_index()
        
        # Create the plot
        plt.figure(figsize=(12, 6))
        sns.barplot(data=hourly_avg, x='Hour', y='StepTotal', color='skyblue')
        
        # Customize the plot
        plt.title('Average Steps by Hour of Day')
        plt.xlabel('Hour (24-hour format)')
        plt.ylabel('Average Steps')
        plt.grid(True, axis='y', linestyle='--', alpha=0.7)
        
        # Add value labels on top of each bar
        for i, v in enumerate(hourly_avg['StepTotal']):
            plt.text(i, v, f'{int(v)}', ha='center', va='bottom')
        
        # Adjust layout and save
        plt.tight_layout()
        plt.savefig('outputs/steps_by_hour.png')
        plt.close()
        
        print("✅ Steps by hour plot generated successfully")
        
    except Exception as e:
        print(f"❌ Error generating steps plot: {str(e)}")


