import pandas as pd
import matplotlib.pyplot as plt
from .load_data import safe_read

def plot_sleep_efficiency():
    """
    Create and save a plot showing sleep efficiency over time.
    """
    # Load sleep data
    sleep_data = safe_read('sleepDay_merged.csv')
    
    if sleep_data.empty:
        print("❌ No sleep data available to plot")
        return
        
    try:
        # Calculate sleep efficiency
        sleep_data['Date'] = pd.to_datetime(sleep_data['SleepDay'])
        sleep_data['SleepEfficiency'] = (
            sleep_data['TotalMinutesAsleep'] / sleep_data['TotalTimeInBed'] * 100
        )
        
        # Create the plot
        plt.figure(figsize=(12, 6))
        plt.plot(sleep_data['Date'], sleep_data['SleepEfficiency'], 
                marker='o', linestyle='-', color='blue')
        
        # Customize the plot
        plt.title('Sleep Efficiency Over Time')
        plt.xlabel('Date')
        plt.ylabel('Sleep Efficiency (%)')
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.xticks(rotation=45)
        
        # Adjust layout and save
        plt.tight_layout()
        plt.savefig('outputs/sleep_efficiency.png')
        plt.close()
        
        print("✅ Sleep efficiency plot generated successfully")
        
    except Exception as e:
        print(f"❌ Error generating sleep plot: {str(e)}")


